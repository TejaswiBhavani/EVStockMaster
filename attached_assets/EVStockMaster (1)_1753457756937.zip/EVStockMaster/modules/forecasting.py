import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_forecast(data, part_name, window_size, forecast_horizon):
    """
    Generate time-series forecast using Simple Moving Average (SMA) method.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        Input DataFrame containing historical demand data
    part_name : str
        Name of the EV part to forecast
    window_size : int
        Number of days to use for moving average calculation
    forecast_horizon : int
        Number of days to forecast into the future
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame containing original data, SMA, and forecast values
    """
    # Filter data for the selected part
    part_data = data[data['part_name'] == part_name].copy()
    
    if part_data.empty:
        print(f"Warning: No data found for part '{part_name}'")
        return pd.DataFrame()
    
    # Sort by date to ensure chronological order
    part_data = part_data.sort_values('date').reset_index(drop=True)
    
    # Calculate Simple Moving Average (SMA)
    part_data['sma'] = part_data['demand'].rolling(
        window=window_size, 
        min_periods=1
    ).mean()
    
    # Get the last date and last SMA value for forecasting
    last_date = part_data['date'].iloc[-1]
    last_sma = part_data['sma'].iloc[-1]
    
    # Generate forecast dates
    forecast_dates = pd.date_range(
        start=last_date + timedelta(days=1),
        periods=forecast_horizon,
        freq='D'
    )
    
    # Create forecast DataFrame
    # For SMA forecasting, we project the last SMA value forward
    forecast_df = pd.DataFrame({
        'part_name': part_name,
        'date': forecast_dates,
        'demand': np.nan,  # No actual demand data for future
        'sma': np.nan,     # No SMA for future (would need actual data)
        'forecast': last_sma  # Project last SMA value forward
    })
    
    # Combine historical data with forecast
    # Add forecast column to historical data (NaN for historical periods)
    part_data['forecast'] = np.nan
    
    # Combine the DataFrames
    result_df = pd.concat([part_data, forecast_df], ignore_index=True)
    
    # Sort by date to maintain chronological order
    result_df = result_df.sort_values('date').reset_index(drop=True)
    
    return result_df

def calculate_forecast_accuracy(actual_data, forecast_data, metric='mae'):
    """
    Calculate forecast accuracy metrics.
    
    Parameters:
    -----------
    actual_data : array-like
        Actual demand values
    forecast_data : array-like
        Forecasted demand values
    metric : str
        Accuracy metric to calculate ('mae', 'mse', 'mape')
        
    Returns:
    --------
    float
        Calculated accuracy metric
    """
    actual = np.array(actual_data)
    forecast = np.array(forecast_data)
    
    # Remove any NaN values
    mask = ~(np.isnan(actual) | np.isnan(forecast))
    actual = actual[mask]
    forecast = forecast[mask]
    
    if len(actual) == 0:
        return np.nan
    
    if metric.lower() == 'mae':
        # Mean Absolute Error
        return np.mean(np.abs(actual - forecast))
    elif metric.lower() == 'mse':
        # Mean Squared Error
        return np.mean((actual - forecast) ** 2)
    elif metric.lower() == 'mape':
        # Mean Absolute Percentage Error
        # Avoid division by zero
        mask = actual != 0
        if np.sum(mask) == 0:
            return np.nan
        return np.mean(np.abs((actual[mask] - forecast[mask]) / actual[mask])) * 100
    else:
        raise ValueError(f"Unknown metric: {metric}")

def optimize_window_size(data, part_name, min_window=7, max_window=90, test_periods=30):
    """
    Find optimal window size for SMA forecasting based on historical accuracy.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        Historical demand data
    part_name : str
        Name of the EV part
    min_window : int
        Minimum window size to test
    max_window : int
        Maximum window size to test
    test_periods : int
        Number of periods to use for testing
        
    Returns:
    --------
    dict
        Dictionary containing optimal window size and accuracy metrics
    """
    part_data = data[data['part_name'] == part_name].copy()
    
    if len(part_data) < max_window + test_periods:
        return {'optimal_window': min_window, 'mae': np.inf, 'mse': np.inf}
    
    part_data = part_data.sort_values('date').reset_index(drop=True)
    
    # Split data into train and test
    train_data = part_data.iloc[:-test_periods]
    test_data = part_data.iloc[-test_periods:]
    
    best_window = min_window
    best_mae = np.inf
    
    results = []
    
    for window in range(min_window, min(max_window + 1, len(train_data))):
        # Calculate SMA on training data
        train_sma = train_data['demand'].rolling(window=window).mean()
        
        # Use last SMA value as forecast for all test periods
        last_sma = train_sma.iloc[-1]
        forecast_values = np.full(len(test_data), last_sma)
        
        # Calculate accuracy
        mae = calculate_forecast_accuracy(test_data['demand'], forecast_values, 'mae')
        mse = calculate_forecast_accuracy(test_data['demand'], forecast_values, 'mse')
        
        results.append({
            'window_size': window,
            'mae': mae,
            'mse': mse
        })
        
        if mae < best_mae:
            best_mae = mae
            best_window = window
    
    return {
        'optimal_window': best_window,
        'mae': best_mae,
        'all_results': results
    }

if __name__ == "__main__":
    """
    Test the forecasting functionality with sample data
    """
    # This would typically load actual data
    print("Testing forecasting module...")
    
    # For testing, we'll create a simple sample
    sample_data = pd.DataFrame({
        'part_name': ['Battery Pack'] * 100,
        'date': pd.date_range(start='2021-01-01', periods=100, freq='D'),
        'demand': np.random.randint(400, 600, 100)
    })
    
    # Test forecast generation
    forecast_result = generate_forecast(
        data=sample_data,
        part_name='Battery Pack',
        window_size=14,
        forecast_horizon=7
    )
    
    print(f"Generated forecast with {len(forecast_result)} total records")
    print(f"Historical records: {forecast_result['demand'].notna().sum()}")
    print(f"Forecast records: {forecast_result['forecast'].notna().sum()}")
    
    # Test accuracy calculation
    actual = np.array([100, 110, 120, 130, 140])
    forecast = np.array([95, 105, 125, 135, 145])
    
    mae = calculate_forecast_accuracy(actual, forecast, 'mae')
    mse = calculate_forecast_accuracy(actual, forecast, 'mse')
    mape = calculate_forecast_accuracy(actual, forecast, 'mape')
    
    print(f"\nAccuracy Metrics Test:")
    print(f"MAE: {mae:.2f}")
    print(f"MSE: {mse:.2f}")
    print(f"MAPE: {mape:.2f}%")
