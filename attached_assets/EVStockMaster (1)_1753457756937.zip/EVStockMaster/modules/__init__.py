"""
GenAI Smart Inventory Optimizer Modules

This package contains the core modules for the EV manufacturing inventory optimization system:
- data_generator: Synthetic data generation for EV parts
- forecasting: Time-series forecasting using Simple Moving Average
- insight_engine: Rule-based insights for inventory management
- analytics: Statistical analysis and leaderboard functionality
"""

__version__ = "1.0.0"
__author__ = "GenAI Inventory Optimizer Team"

# Make modules easily importable
from .data_generator import generate_inventory_data
from .forecasting import generate_forecast
from .insight_engine import generate_insights
from .analytics import calculate_part_statistics, generate_leaderboard

__all__ = [
    'generate_inventory_data',
    'generate_forecast', 
    'generate_insights',
    'calculate_part_statistics',
    'generate_leaderboard'
]
