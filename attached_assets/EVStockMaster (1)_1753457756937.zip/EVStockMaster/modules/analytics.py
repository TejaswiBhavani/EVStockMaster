import pandas as pd
import numpy as np
from scipy import stats
import plotly.express as px
import plotly.graph_objects as go

def calculate_part_statistics(data, part_name):
    """
    Calculate comprehensive statistics for a specific EV part.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        Historical inventory data
    part_name : str
        Name of the EV part to analyze
        
    Returns:
    --------
    dict
        Dictionary containing various statistical metrics
    """
    # Filter data for the specific part
    part_data = data[data['part_name'] == part_name].copy()
    
    if part_data.empty:
        return None
    
    # Sort by date
    part_data = part_data.sort_values('date')
    demand_values = part_data['demand'].values
    
    # Basic statistics
    basic_stats = {
        'mean_demand': np.mean(demand_values),
        'median_demand': np.median(demand_values),
        'std_demand': np.std(demand_values, ddof=1),
        'min_demand': np.min(demand_values),
        'max_demand': np.max(demand_values),
        'total_demand': np.sum(demand_values),
        'demand_range': np.max(demand_values) - np.min(demand_values),
        'coefficient_of_variation': np.std(demand_values, ddof=1) / np.mean(demand_values) * 100
    }
    
    # Trend analysis using linear regression
    x = np.arange(len(demand_values))
    slope, intercept, r_value, p_value, std_err = stats.linregress(x, demand_values)
    
    trend_stats = {
        'trend_slope': slope,
        'trend_intercept': intercept,
        'trend_r_squared': r_value ** 2,
        'trend_p_value': p_value,
        'trend_direction': 'Increasing' if slope > 0 else 'Decreasing' if slope < 0 else 'Stable'
    }
    
    # Seasonality analysis (simplified)
    part_data['month'] = part_data['date'].dt.month
    monthly_avg = part_data.groupby('month')['demand'].mean()
    seasonality_stats = {
        'seasonal_peak_month': monthly_avg.idxmax(),
        'seasonal_low_month': monthly_avg.idxmin(),
        'seasonal_variation': monthly_avg.max() - monthly_avg.min(),
        'seasonal_coefficient': (monthly_avg.std() / monthly_avg.mean()) * 100
    }
    
    # Volatility analysis
    part_data['demand_change'] = part_data['demand'].pct_change()
    volatility_stats = {
        'daily_volatility': part_data['demand_change'].std() * 100,
        'max_daily_increase': part_data['demand_change'].max() * 100,
        'max_daily_decrease': part_data['demand_change'].min() * 100
    }
    
    # Quality metrics
    quality_stats = {
        'data_points': len(demand_values),
        'date_range_days': (part_data['date'].max() - part_data['date'].min()).days,
        'missing_values': part_data['demand'].isna().sum(),
        'outliers_count': len(detect_outliers(demand_values))
    }
    
    # Combine all statistics
    all_stats = {
        **basic_stats,
        **trend_stats,
        **seasonality_stats,
        **volatility_stats,
        **quality_stats
    }
    
    return all_stats

def generate_leaderboard(data, sort_by='avg_demand'):
    """
    Generate a performance leaderboard for all EV parts.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        Historical inventory data for all parts
    sort_by : str
        Metric to sort by ('avg_demand', 'total_demand', 'trend_slope', 'volatility')
        
    Returns:
    --------
    pandas.DataFrame
        Leaderboard DataFrame sorted by the specified metric
    """
    if data.empty:
        return pd.DataFrame()
    
    # Calculate metrics for each part
    parts_metrics = []
    
    for part_name in data['part_name'].unique():
        stats = calculate_part_statistics(data, part_name)
        if stats:
            part_metrics = {
                'part_name': part_name,
                'avg_demand': stats['mean_demand'],
                'total_demand': stats['total_demand'],
                'trend_slope': stats['trend_slope'],
                'volatility': stats['daily_volatility'],
                'coefficient_of_variation': stats['coefficient_of_variation'],
                'r_squared': stats['trend_r_squared'],
                'seasonal_variation': stats['seasonal_variation'],
                'data_quality_score': calculate_data_quality_score(stats)
            }
            parts_metrics.append(part_metrics)
    
    # Create leaderboard DataFrame
    leaderboard_df = pd.DataFrame(parts_metrics)
    
    if leaderboard_df.empty:
        return leaderboard_df
    
    # Sort by specified metric (descending for most metrics)
    ascending = sort_by in ['volatility', 'coefficient_of_variation']  # Lower is better for these
    leaderboard_df = leaderboard_df.sort_values(by=sort_by, ascending=ascending)
    
    # Add ranking
    leaderboard_df['rank'] = range(1, len(leaderboard_df) + 1)
    
    # Round numerical values for display
    numerical_columns = ['avg_demand', 'total_demand', 'trend_slope', 'volatility', 
                        'coefficient_of_variation', 'r_squared', 'seasonal_variation', 
                        'data_quality_score']
    
    for col in numerical_columns:
        if col in leaderboard_df.columns:
            leaderboard_df[col] = leaderboard_df[col].round(2)
    
    return leaderboard_df

def calculate_data_quality_score(stats):
    """
    Calculate a data quality score based on various metrics.
    
    Parameters:
    -----------
    stats : dict
        Statistics dictionary from calculate_part_statistics
        
    Returns:
    --------
    float
        Data quality score (0-100)
    """
    score = 100
    
    # Penalize missing values
    if stats['missing_values'] > 0:
        missing_penalty = (stats['missing_values'] / stats['data_points']) * 20
        score -= missing_penalty
    
    # Penalize excessive outliers
    if stats['outliers_count'] > 0:
        outlier_penalty = min((stats['outliers_count'] / stats['data_points']) * 30, 15)
        score -= outlier_penalty
    
    # Reward sufficient data points
    if stats['data_points'] < 30:
        score -= 20
    elif stats['data_points'] < 90:
        score -= 10
    
    # Reward good date coverage
    if stats['date_range_days'] < 30:
        score -= 15
    elif stats['date_range_days'] < 90:
        score -= 5
    
    return max(score, 0)  # Ensure score doesn't go below 0

def detect_outliers(data, method='iqr', threshold=1.5):
    """
    Detect outliers in demand data.
    
    Parameters:
    -----------
    data : array-like
        Demand values
    method : str
        Method for outlier detection ('iqr', 'zscore')
    threshold : float
        Threshold for outlier detection
        
    Returns:
    --------
    list
        Indices of outliers
    """
    data = np.array(data)
    outliers = []
    
    if method == 'iqr':
        Q1 = np.percentile(data, 25)
        Q3 = np.percentile(data, 75)
        IQR = Q3 - Q1
        
        lower_bound = Q1 - threshold * IQR
        upper_bound = Q3 + threshold * IQR
        
        outliers = np.where((data < lower_bound) | (data > upper_bound))[0]
    
    elif method == 'zscore':
        z_scores = np.abs(stats.zscore(data))
        outliers = np.where(z_scores > threshold)[0]
    
    return outliers.tolist()

def generate_comparative_analysis(data, parts_list=None):
    """
    Generate comparative analysis between multiple EV parts.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        Historical inventory data
    parts_list : list, optional
        List of parts to compare. If None, compare all parts.
        
    Returns:
    --------
    dict
        Comparative analysis results
    """
    if parts_list is None:
        parts_list = data['part_name'].unique().tolist()
    
    comparison_data = []
    
    for part in parts_list:
        stats = calculate_part_statistics(data, part)
        if stats:
            comparison_data.append({
                'part_name': part,
                'avg_demand': stats['mean_demand'],
                'volatility': stats['daily_volatility'],
                'trend_slope': stats['trend_slope'],
                'seasonal_variation': stats['seasonal_variation']
            })
    
    comparison_df = pd.DataFrame(comparison_data)
    
    if comparison_df.empty:
        return {'error': 'No valid data for comparison'}
    
    # Calculate relative performance metrics
    analysis = {
        'highest_demand': comparison_df.loc[comparison_df['avg_demand'].idxmax(), 'part_name'],
        'lowest_demand': comparison_df.loc[comparison_df['avg_demand'].idxmin(), 'part_name'],
        'most_volatile': comparison_df.loc[comparison_df['volatility'].idxmax(), 'part_name'],
        'least_volatile': comparison_df.loc[comparison_df['volatility'].idxmin(), 'part_name'],
        'strongest_growth': comparison_df.loc[comparison_df['trend_slope'].idxmax(), 'part_name'],
        'weakest_growth': comparison_df.loc[comparison_df['trend_slope'].idxmin(), 'part_name'],
        'most_seasonal': comparison_df.loc[comparison_df['seasonal_variation'].idxmax(), 'part_name'],
        'least_seasonal': comparison_df.loc[comparison_df['seasonal_variation'].idxmin(), 'part_name'],
        'comparison_data': comparison_df
    }
    
    return analysis

def calculate_inventory_efficiency_metrics(data, part_name, current_stock, holding_cost_per_unit=1.0):
    """
    Calculate inventory efficiency metrics for a specific part.
    
    Parameters:
    -----------
    data : pandas.DataFrame
        Historical inventory data
    part_name : str
        Name of the EV part
    current_stock : int
        Current stock level
    holding_cost_per_unit : float
        Cost to hold one unit in inventory per day
        
    Returns:
    --------
    dict
        Inventory efficiency metrics
    """
    stats = calculate_part_statistics(data, part_name)
    
    if not stats:
        return {'error': f'No data available for {part_name}'}
    
    avg_demand = stats['mean_demand']
    
    # Calculate key efficiency metrics
    inventory_turnover = (avg_demand * 365) / max(current_stock, 1)  # Annual turnover
    days_of_inventory = current_stock / max(avg_demand, 1)  # Days of stock
    holding_cost_per_day = current_stock * holding_cost_per_unit
    holding_cost_per_year = holding_cost_per_day * 365
    
    # Efficiency ratings
    efficiency_rating = 'High' if inventory_turnover > 12 else 'Medium' if inventory_turnover > 6 else 'Low'
    
    return {
        'inventory_turnover': round(inventory_turnover, 2),
        'days_of_inventory': round(days_of_inventory, 1),
        'holding_cost_per_day': round(holding_cost_per_day, 2),
        'holding_cost_per_year': round(holding_cost_per_year, 2),
        'efficiency_rating': efficiency_rating,
        'avg_demand': round(avg_demand, 2),
        'current_stock': current_stock
    }

if __name__ == "__main__":
    """
    Test the analytics functionality
    """
    print("Testing analytics module...")
    
    # Create sample data for testing
    np.random.seed(42)
    sample_parts = ['Battery Pack', 'Electric Motor', 'Charging Port']
    sample_data = []
    
    for part in sample_parts:
        dates = pd.date_range(start='2021-01-01', periods=365, freq='D')
        base_demand = np.random.randint(400, 800)
        trend = np.linspace(0, 50, 365)
        seasonality = 50 * np.sin(2 * np.pi * np.arange(365) / 365)
        noise = np.random.normal(0, 30, 365)
        demand = base_demand + trend + seasonality + noise
        demand = np.maximum(demand, 0)  # No negative demand
        
        part_df = pd.DataFrame({
            'part_name': part,
            'date': dates,
            'demand': demand
        })
        sample_data.append(part_df)
    
    test_data = pd.concat(sample_data, ignore_index=True)
    
    # Test statistics calculation
    print("\n=== Testing Statistics Calculation ===")
    stats = calculate_part_statistics(test_data, 'Battery Pack')
    if stats:
        print(f"Mean demand: {stats['mean_demand']:.2f}")
        print(f"Trend slope: {stats['trend_slope']:.2f}")
        print(f"R-squared: {stats['trend_r_squared']:.3f}")
        print(f"Seasonal variation: {stats['seasonal_variation']:.2f}")
    
    # Test leaderboard generation
    print("\n=== Testing Leaderboard Generation ===")
    leaderboard = generate_leaderboard(test_data, sort_by='avg_demand')
    print(leaderboard[['part_name', 'avg_demand', 'trend_slope', 'volatility']].head())
    
    # Test comparative analysis
    print("\n=== Testing Comparative Analysis ===")
    comparison = generate_comparative_analysis(test_data)
    if 'error' not in comparison:
        print(f"Highest demand part: {comparison['highest_demand']}")
        print(f"Most volatile part: {comparison['most_volatile']}")
        print(f"Strongest growth part: {comparison['strongest_growth']}")
    
    # Test inventory efficiency
    print("\n=== Testing Inventory Efficiency ===")
    efficiency = calculate_inventory_efficiency_metrics(
        test_data, 'Battery Pack', current_stock=10000, holding_cost_per_unit=0.5
    )
    if 'error' not in efficiency:
        print(f"Inventory turnover: {efficiency['inventory_turnover']}")
        print(f"Days of inventory: {efficiency['days_of_inventory']}")
        print(f"Efficiency rating: {efficiency['efficiency_rating']}")
