import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_insights(forecast_df, current_stock, reorder_threshold_days):
    """
    Generate actionable inventory insights based on forecast data and current stock levels.
    
    Parameters:
    -----------
    forecast_df : pandas.DataFrame
        DataFrame containing forecast data with 'forecast' column
    current_stock : int
        Current inventory level
    reorder_threshold_days : int
        Number of days of stock to maintain before reordering
        
    Returns:
    --------
    dict
        Dictionary containing status, recommendation, and detailed explanation
    """
    if forecast_df.empty or 'forecast' not in forecast_df.columns:
        return {
            'status': 'Error',
            'recommendation': 'Unable to generate insights',
            'details': 'No forecast data available. Please check your data and try again.'
        }
    
    # Get forecast values (excluding NaN)
    forecast_values = forecast_df['forecast'].dropna()
    
    if forecast_values.empty:
        return {
            'status': 'Error',
            'recommendation': 'Unable to generate insights',
            'details': 'No valid forecast data found. The forecasting model may need more historical data.'
        }
    
    # Calculate average daily forecasted demand
    avg_daily_demand = forecast_values.mean()
    
    # Calculate total forecasted demand over the reorder threshold period
    total_forecasted_demand = avg_daily_demand * reorder_threshold_days
    
    # Calculate days of stock remaining
    days_of_stock = current_stock / max(avg_daily_demand, 1)  # Avoid division by zero
    
    # Apply business rules to determine status and recommendations
    
    # Rule 1: Critical - Current stock is less than forecasted demand over threshold period
    if current_stock < total_forecasted_demand:
        status = 'Critical'
        recommendation = 'Reorder Immediately'
        details = (f"Current stock ({current_stock:,} units) will be depleted in {days_of_stock:.1f} days "
                  f"based on forecasted demand of {avg_daily_demand:.0f} units/day. "
                  f"You need {total_forecasted_demand:.0f} units to cover the next {reorder_threshold_days} days. "
                  f"Shortage risk: {total_forecasted_demand - current_stock:.0f} units.")
    
    # Rule 2: Warning - Current stock is less than 150% of forecasted demand over threshold period
    elif current_stock < (total_forecasted_demand * 1.5):
        status = 'Warning'
        recommendation = 'Consider Reordering Soon'
        buffer_needed = total_forecasted_demand * 1.5
        details = (f"Current stock ({current_stock:,} units) provides {days_of_stock:.1f} days of coverage. "
                  f"Recommended safety buffer is 150% of {reorder_threshold_days}-day demand "
                  f"({buffer_needed:.0f} units). "
                  f"Consider reordering {buffer_needed - current_stock:.0f} units to maintain optimal levels.")
    
    # Rule 3: Healthy - Stock level is sufficient
    else:
        status = 'Healthy'
        recommendation = 'No Action Needed'
        excess_stock = current_stock - total_forecasted_demand
        details = (f"Current stock ({current_stock:,} units) provides {days_of_stock:.1f} days of coverage, "
                  f"which exceeds the {reorder_threshold_days}-day requirement. "
                  f"Excess inventory: {excess_stock:.0f} units. "
                  f"Next review recommended in {days_of_stock - reorder_threshold_days:.0f} days.")
    
    # Additional insights
    insights_dict = {
        'status': status,
        'recommendation': recommendation,
        'details': details,
        'metrics': {
            'current_stock': current_stock,
            'avg_daily_demand': round(avg_daily_demand, 2),
            'days_of_stock': round(days_of_stock, 2),
            'total_forecasted_demand': round(total_forecasted_demand, 2),
            'reorder_threshold_days': reorder_threshold_days
        }
    }
    
    return insights_dict

def calculate_safety_stock(historical_data, service_level=0.95, lead_time_days=14):
    """
    Calculate recommended safety stock levels based on demand variability.
    
    Parameters:
    -----------
    historical_data : pandas.DataFrame or array-like
        Historical demand data
    service_level : float
        Desired service level (e.g., 0.95 for 95%)
    lead_time_days : int
        Lead time in days
        
    Returns:
    --------
    dict
        Dictionary containing safety stock calculation details
    """
    if isinstance(historical_data, pd.DataFrame):
        if 'demand' in historical_data.columns:
            demand_data = historical_data['demand'].dropna()
        else:
            return {'error': 'No demand column found in DataFrame'}
    else:
        demand_data = np.array(historical_data)
        demand_data = demand_data[~np.isnan(demand_data)]
    
    if len(demand_data) == 0:
        return {'error': 'No valid demand data provided'}
    
    # Calculate demand statistics
    mean_demand = np.mean(demand_data)
    std_demand = np.std(demand_data, ddof=1)  # Sample standard deviation
    
    # Z-score for service level (assuming normal distribution)
    z_scores = {
        0.90: 1.28,
        0.95: 1.65,
        0.99: 2.33
    }
    
    z_score = z_scores.get(service_level, 1.65)  # Default to 95%
    
    # Safety stock calculation: z_score * std_demand * sqrt(lead_time)
    safety_stock = z_score * std_demand * np.sqrt(lead_time_days)
    
    # Reorder point calculation
    reorder_point = (mean_demand * lead_time_days) + safety_stock
    
    return {
        'safety_stock': round(safety_stock, 0),
        'reorder_point': round(reorder_point, 0),
        'mean_demand': round(mean_demand, 2),
        'std_demand': round(std_demand, 2),
        'service_level': service_level,
        'lead_time_days': lead_time_days,
        'z_score': z_score
    }

def generate_procurement_plan(insights, lead_time_days=14, order_quantity_multiplier=1.2):
    """
    Generate a procurement plan based on insights.
    
    Parameters:
    -----------
    insights : dict
        Insights dictionary from generate_insights function
    lead_time_days : int
        Procurement lead time in days
    order_quantity_multiplier : float
        Multiplier for order quantity to account for safety stock
        
    Returns:
    --------
    dict
        Procurement plan with recommended actions
    """
    if 'metrics' not in insights:
        return {'error': 'Invalid insights data provided'}
    
    metrics = insights['metrics']
    status = insights['status']
    
    # Calculate recommended order quantity
    daily_demand = metrics['avg_daily_demand']
    lead_time_demand = daily_demand * lead_time_days
    
    if status == 'Critical':
        # Urgent order: cover lead time + safety buffer
        order_quantity = lead_time_demand * order_quantity_multiplier
        urgency = 'Immediate'
        timeline = 'Rush order recommended'
    elif status == 'Warning':
        # Standard order: normal procurement process
        order_quantity = lead_time_demand
        urgency = 'Standard'
        timeline = f'Order within next {lead_time_days//2} days'
    else:
        # No immediate order needed
        order_quantity = 0
        urgency = 'None'
        timeline = 'Monitor inventory levels'
    
    procurement_plan = {
        'order_quantity': round(order_quantity, 0),
        'urgency_level': urgency,
        'recommended_timeline': timeline,
        'lead_time_days': lead_time_days,
        'estimated_cost_per_unit': 'To be determined',  # Would come from ERP system
        'supplier_recommendations': 'Primary supplier preferred for standard orders'
    }
    
    return procurement_plan

if __name__ == "__main__":
    """
    Test the insight engine functionality
    """
    print("Testing insight engine...")
    
    # Create sample forecast data
    sample_forecast = pd.DataFrame({
        'date': pd.date_range(start='2024-01-01', periods=30, freq='D'),
        'forecast': np.random.normal(500, 50, 30)  # Mean=500, std=50
    })
    
    # Test case 1: Critical status
    print("\n=== Test Case 1: Critical Status ===")
    insights_critical = generate_insights(
        forecast_df=sample_forecast,
        current_stock=5000,  # Low stock
        reorder_threshold_days=14
    )
    
    print(f"Status: {insights_critical['status']}")
    print(f"Recommendation: {insights_critical['recommendation']}")
    print(f"Details: {insights_critical['details']}")
    
    # Test case 2: Warning status  
    print("\n=== Test Case 2: Warning Status ===")
    insights_warning = generate_insights(
        forecast_df=sample_forecast,
        current_stock=8000,  # Moderate stock
        reorder_threshold_days=14
    )
    
    print(f"Status: {insights_warning['status']}")
    print(f"Recommendation: {insights_warning['recommendation']}")
    print(f"Details: {insights_warning['details']}")
    
    # Test case 3: Healthy status
    print("\n=== Test Case 3: Healthy Status ===")
    insights_healthy = generate_insights(
        forecast_df=sample_forecast,
        current_stock=15000,  # High stock
        reorder_threshold_days=14
    )
    
    print(f"Status: {insights_healthy['status']}")
    print(f"Recommendation: {insights_healthy['recommendation']}")
    print(f"Details: {insights_healthy['details']}")
    
    # Test safety stock calculation
    print("\n=== Safety Stock Calculation Test ===")
    historical_demand = np.random.normal(500, 100, 365)  # One year of data
    safety_stock_info = calculate_safety_stock(historical_demand, service_level=0.95, lead_time_days=14)
    
    print(f"Recommended Safety Stock: {safety_stock_info['safety_stock']} units")
    print(f"Reorder Point: {safety_stock_info['reorder_point']} units")
    print(f"Service Level: {safety_stock_info['service_level']*100}%")
    
    # Test procurement plan
    print("\n=== Procurement Plan Test ===")
    procurement_plan = generate_procurement_plan(insights_critical, lead_time_days=14)
    
    print(f"Order Quantity: {procurement_plan['order_quantity']} units")
    print(f"Urgency Level: {procurement_plan['urgency_level']}")
    print(f"Timeline: {procurement_plan['recommended_timeline']}")
