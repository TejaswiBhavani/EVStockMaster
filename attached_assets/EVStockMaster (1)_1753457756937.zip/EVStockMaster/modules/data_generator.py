import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_inventory_data(part_name, start_date='2021-01-01', years=3, base_demand=1000, 
                          trend_slope=50, seasonality_strength=200, noise_level=100, random_seed=42):
    """
    Generate synthetic daily demand data for a specific EV part.
    
    Parameters:
    -----------
    part_name : str
        Name of the EV part
    start_date : str
        Start date for data generation (YYYY-MM-DD format)
    years : int
        Number of years of data to generate
    base_demand : int
        Base level of daily demand
    trend_slope : float
        Linear trend slope (demand increase per year)
    seasonality_strength : float
        Amplitude of seasonal variation
    noise_level : float
        Standard deviation of random noise
    random_seed : int
        Random seed for reproducible results
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame with 'part_name', 'date', and 'demand' columns
    """
    # Set random seed for reproducibility
    np.random.seed(random_seed)
    
    # Generate date range
    start = pd.to_datetime(start_date)
    end = start + timedelta(days=years * 365)
    date_range = pd.date_range(start=start, end=end, freq='D')
    
    # Number of days
    n_days = len(date_range)
    
    # Generate time index for calculations (0 to n_days-1)
    time_index = np.arange(n_days)
    
    # Component 1: Linear trend
    # Convert time index to years for trend calculation
    time_in_years = time_index / 365.25
    trend = trend_slope * time_in_years
    
    # Component 2: Annual seasonality (sinusoidal pattern)
    # One complete cycle per year (2*pi radians per 365.25 days)
    seasonality = seasonality_strength * np.sin(2 * np.pi * time_index / 365.25)
    
    # Component 3: Random Gaussian noise
    noise = np.random.normal(0, noise_level, n_days)
    
    # Combine all components
    demand = base_demand + trend + seasonality + noise
    
    # Ensure demand values are not negative
    demand = np.maximum(demand, 0)
    
    # Create DataFrame
    df = pd.DataFrame({
        'part_name': part_name,
        'date': date_range,
        'demand': demand.round().astype(int)
    })
    
    return df

if __name__ == "__main__":
    """
    Generate synthetic data for multiple EV parts and save to CSV
    """
    # Define EV parts with different characteristics
    parts_config = [
        {
            'name': 'Battery Pack',
            'base_demand': 500,
            'trend_slope': 25,
            'seasonality_strength': 150,
            'noise_level': 80,
            'random_seed': 42
        },
        {
            'name': 'Electric Motor', 
            'base_demand': 800,
            'trend_slope': 40,
            'seasonality_strength': 200,
            'noise_level': 120,
            'random_seed': 43
        },
        {
            'name': 'Charging Port',
            'base_demand': 1200,
            'trend_slope': 60,
            'seasonality_strength': 300,
            'noise_level': 150,
            'random_seed': 44
        }
    ]
    
    # Generate data for each part
    all_data = []
    for part_config in parts_config:
        print(f"Generating data for {part_config['name']}...")
        
        part_data = generate_inventory_data(
            part_name=part_config['name'],
            base_demand=part_config['base_demand'],
            trend_slope=part_config['trend_slope'],
            seasonality_strength=part_config['seasonality_strength'],
            noise_level=part_config['noise_level'],
            random_seed=part_config['random_seed']
        )
        
        all_data.append(part_data)
    
    # Combine all parts data
    combined_data = pd.concat(all_data, ignore_index=True)
    
    # Create data directory if it doesn't exist
    import os
    os.makedirs('data', exist_ok=True)
    
    # Save to CSV
    output_file = 'data/synthetic_parts_demand.csv'
    combined_data.to_csv(output_file, index=False)
    
    print(f"\nData generation complete!")
    print(f"Total records: {len(combined_data):,}")
    print(f"Parts included: {', '.join(combined_data['part_name'].unique())}")
    print(f"Date range: {combined_data['date'].min()} to {combined_data['date'].max()}")
    print(f"Data saved to: {output_file}")
    
    # Display summary statistics
    print("\nSummary Statistics:")
    summary = combined_data.groupby('part_name')['demand'].agg([
        'count', 'mean', 'std', 'min', 'max'
    ]).round(2)
    print(summary)
